function setup() {
  createCanvas(400, 400)
}

function draw() {
  background(220);
}let caminhaoX = 0;

let estado = "indo";

let tempoEntrega = 0;

function setup() {

  createCanvas(500, 200);

  textSize(14);

  textAlign(CENTER);

}

function draw() {

  background(135, 206, 235);

  desenharCenario();

  desenharCaminhao(caminhaoX);

  if (estado === "indo") {

    caminhaoX += 2;

    if (caminhaoX >= 250) {

      estado = "entregando";

      tempoEntrega = millis();

    }

  } else if (estado === "entregando") {

    fill(0);

    text("Aqui está seu produto,quando quiser é só chamar!", 300, 140);

    if (millis() - tempoEntrega > 5000) {

      estado = "indoEmbora";

    }

  } else if (estado === "indoEmbora") {

    caminhaoX += 2;

  }

}

function desenharCenario() {

  // Campo com casas

  fill(34, 139, 34);

  rect(0, 150, 800, 50);

  fill(255);

  rect(30, 120, 30, 30)

  rect(80, 120, 30, 30);

  fill(200, 0, 0);

  triangle(30, 120, 45, 100, 60, 120);

  triangle(80, 120, 95, 100, 110, 120);

  // Cidade com prédios

  fill(80);

  rect(200, 150, 200, 50);

  fill(100);

  rect(270, 100, 30, 50);

  rect(320, 90, 30, 60);

  fill(275);

  rect(278, 110, 10, 10);

  rect(328, 100, 10, 10);

}

function desenharCaminhao(x) {

  fill(255, 0, 0);

  rect(x, 130, 40, 20);

  fill(200, 90, 0);

  rect(x + 25, 120, 15, 15);

  fill(0);

  ellipse(x + 10, 150, 10);

  ellipse(x + 35, 150, 10);

}